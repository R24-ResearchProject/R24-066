import React from 'react';
import  { Redirect } from 'react-router-dom';


export const handleErrors = (error) =>{
    // console.log(error);
    console.log(error);
    // return (<Redirect to="/error"/>)
    // return <Redirect path={Test} to="*"/>
}


// RESPONSE CHECK
// if(!res.ok){throw new Error("Message")}
